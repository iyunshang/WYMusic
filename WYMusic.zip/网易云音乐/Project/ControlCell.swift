//
//  ControlCell.swift
//  Project
//
//  Created by 姜建勇 on 16/8/3.
//  Copyright © 2016年 姜建勇. All rights reserved.
//

import UIKit

class ControlCell: UICollectionViewCell {
    
}
